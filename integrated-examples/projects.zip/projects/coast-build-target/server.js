const http = require("http");
const fs = require("fs");

// The dev stage does NOT have /app/stage.txt, the prod stage does.
// This lets us verify which stage was built.
const stage = fs.existsSync("/app/stage.txt") ? "production" : "development";

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200);
    res.end("ok");
    return;
  }
  if (req.url === "/stage") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ stage }));
    return;
  }
  res.writeHead(200);
  res.end("hello");
});

server.listen(3000, () => console.log("listening on 3000"));
