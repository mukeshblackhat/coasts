const http = require("http");
const os = require("os");

const PORT = 3000;

const server = http.createServer((req, res) => {
  const json = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  if (req.url === "/health") {
    return json({ status: "ok" });
  }

  return json({
    service: "api",
    message: "Hello from Coast mixed services (compose API)!",
    hostname: os.hostname(),
    uptime: process.uptime(),
  });
});

server.listen(PORT, () => {
  console.log(`API server listening on port ${PORT}`);
});
