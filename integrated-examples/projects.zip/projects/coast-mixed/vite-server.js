const http = require("http");
const os = require("os");

const PORT = 40100;

const server = http.createServer((req, res) => {
  const json = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  if (req.url === "/health") {
    return json({ status: "ok" });
  }

  return json({
    service: "vite",
    message: "Hello from Coast mixed services (bare vite)!",
    hostname: os.hostname(),
    uptime: process.uptime(),
  });
});

server.listen(PORT, () => {
  console.log(`Vite dev server listening on port ${PORT}`);
});
