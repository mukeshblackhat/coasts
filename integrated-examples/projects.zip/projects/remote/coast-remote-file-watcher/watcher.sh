#!/bin/bash
# Simulate a dev server (like React Router) that regenerates a +types
# directory whenever workspace files change. This creates a race
# condition when rsync writes files during coast assign.

WATCH_DIR=/workspace
GENERATED_DIR=/workspace/.generated-types/app/+types

mkdir -p "$GENERATED_DIR"
echo "generated on startup" > "$GENERATED_DIR/root.ts"
echo "watcher: initial +types created"

LAST_HASH=""
while true; do
    HASH=$(find "$WATCH_DIR" -maxdepth 2 -name "*.js" -newer "$GENERATED_DIR/root.ts" 2>/dev/null | md5sum 2>/dev/null || echo "")
    if [ "$HASH" != "$LAST_HASH" ] && [ -n "$LAST_HASH" ]; then
        echo "watcher: change detected, regenerating +types"
        rm -rf "$GENERATED_DIR"
        sleep 0.05
        mkdir -p "$GENERATED_DIR"
        echo "regenerated at $(date)" > "$GENERATED_DIR/root.ts"
    fi
    LAST_HASH="$HASH"
    sleep 0.2
done
