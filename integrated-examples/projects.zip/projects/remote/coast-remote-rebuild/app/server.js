const http = require("http");
const fs = require("fs");

const PORT = 3000;
const VERSION = fs.readFileSync("/app/version.txt", "utf8").trim();

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200);
    res.end("ok");
    return;
  }
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ version: VERSION }));
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Rebuild test server ${VERSION} on port ${PORT}`);
});
