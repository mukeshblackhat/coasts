const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = 40500;
const DATA_PATH = path.join(__dirname, "data.json");

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200);
    res.end("ok");
    return;
  }
  try {
    const data = fs.readFileSync(DATA_PATH, "utf8");
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(data);
  } catch (e) {
    res.writeHead(500);
    res.end(JSON.stringify({ error: e.message }));
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`HMR test server on port ${PORT}`);
});
