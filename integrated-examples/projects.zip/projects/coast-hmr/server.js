const http = require("http");
const fs = require("fs");
const path = require("path");

const server = http.createServer((req, res) => {
  const json = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  if (req.url === "/health") return json({ status: "ok" });

  try {
    const raw = fs.readFileSync(path.join("/app", "data.json"), "utf8");
    return json(JSON.parse(raw));
  } catch (err) {
    return json({ error: err.message }, 500);
  }
});

server.listen(3000, () => console.log("HMR test server on :3000"));
