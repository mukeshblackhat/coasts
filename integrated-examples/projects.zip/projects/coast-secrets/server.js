const http = require("http");
const fs = require("fs");

const PORT = 3000;

const server = http.createServer(async (req, res) => {
  const json = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  try {
    if (req.url === "/health") {
      return json({ status: "ok" });
    }

    if (req.url === "/secrets") {
      return json({
        file_secret: process.env.FILE_SECRET || null,
        env_secret: process.env.ENV_SECRET || null,
        cmd_secret: process.env.CMD_SECRET || null,
      });
    }

    if (req.url === "/secret-file") {
      try {
        const content = fs.readFileSync("/run/secrets/test_secret", "utf8");
        return json({ content: content.trim() });
      } catch (err) {
        return json({ content: null, error: err.message });
      }
    }

    // Default: homepage
    return json({
      service: "coast-secrets",
      branch: "main",
    });
  } catch (err) {
    console.error("Request error:", err);
    json({ error: err.message }, 500);
  }
});

server.listen(PORT, () => {
  console.log(`Coast secrets demo listening on :${PORT}`);
});
