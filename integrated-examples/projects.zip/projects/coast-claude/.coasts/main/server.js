const http = require("http");

const PORT = 39000;

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ status: "ok" }));
    return;
  }

  if (req.url === "/") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(
      JSON.stringify({
        service: "coast-claude",
        branch: "main",
        description: "Claude Code demo — exec in and run claude",
      })
    );
    return;
  }

  if (req.url === "/check-auth") {
    // Check whether ANTHROPIC_API_KEY is present (don't expose the value!)
    const hasKey = !!process.env.ANTHROPIC_API_KEY;
    const keyPrefix = hasKey
      ? process.env.ANTHROPIC_API_KEY.substring(0, 10) + "..."
      : null;
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(
      JSON.stringify({
        anthropic_api_key_present: hasKey,
        key_prefix: keyPrefix,
      })
    );
    return;
  }

  res.writeHead(404, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ error: "not found" }));
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`coast-claude health server listening on port ${PORT}`);
});
